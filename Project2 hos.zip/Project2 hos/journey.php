<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    .journey-section {
  padding: 60px 20px;
  background-color: rgba(255, 255, 255, 0.9);
  animation: fadeIn 2s ease-in-out;
}

.journey-container {
  max-width: 1000px;
  margin: auto;
  text-align: center;
}

.journey-container h2 {
  font-size: 36px;
  color: #d31532ff;
  margin-bottom: 20px;
  border-bottom: 3px solid #007bff;
  display: inline-block;
  padding-bottom: 8px;
}

.journey-container p {
  font-size: 18px;
  color: #333;
  margin-bottom: 40px;
  line-height: 1.6;
}

.timeline {
  display: flex;
  flex-direction: column;
  gap: 25px;
  align-items: flex-start;
  padding-left: 20px;
  border-left: 3px solid #ac119fff;
  position: relative;
}

.timeline-event {
  position: relative;
  padding-left: 20px;
}

.timeline-event::before {
  content: '';
  position: absolute;
  top: 4px;
  left: -12px;
  width: 14px;
  height: 14px;
  background-color: #e78e19ff;
  border-radius: 50%;
}

.timeline-event .year {
  font-weight: bold;
  color: #13e9f4ff;
  font-size: 18px;
  margin-bottom: 5px;
  display: inline-block;
}
</style>
</head>
<body>
    <section id="OurJourney" class="journey-section">
  <div class="journey-container">
    <h2>Our Journey</h2>
    <p>
      Since our founding, our hospital has grown from a humble clinic to a leading center of medical excellence.
      Our journey is one of innovation, dedication, and a relentless focus on quality care for every patient.
    </p>

    <div class="timeline">
      <div class="timeline-event">
        <span class="year">2000</span>
        <p>Established with a small but passionate medical team and a goal to make healthcare more accessible.</p>
      </div>
      <div class="timeline-event">
        <span class="year">2010</span>
        <p>Expanded to a multi-specialty facility with new departments, labs, and advanced diagnostic equipment.</p>
      </div>
      <div class="timeline-event">
        <span class="year">2020</span>
        <p>Recognized nationally for excellence in patient safety, innovation, and community outreach.</p>
      </div>
      <div class="timeline-event">
        <span class="year">2025</span>
        <p>Continuing to serve thousands of patients with world-class care, research, and compassionate service.</p>
      </div>
    </div>
  </div>
</section>

</body>
</html>