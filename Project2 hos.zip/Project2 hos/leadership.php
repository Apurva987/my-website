<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        .leadership-section {
  padding: 60px 20px;
  background-color: rgba(14, 170, 24, 0.95);
  animation: fadeIn 2s ease-in-out;
}


.leadership-container {
  max-width: 1100px;
  margin: auto;
  text-align: center;
}

.leadership-container h2 {
  font-size: 36px;
  color: #007bff;
  margin-bottom: 20px;
  border-bottom: 3px solid #007bff;
  display: inline-block;
  padding-bottom: 8px;
}

.leadership-container p {
  font-size: 18px;
  color: #333;
  margin-bottom: 40px;
  line-height: 1.6;
}

.leaders {
  display: flex;
  flex-wrap: wrap;
  gap: 25px;
  justify-content: center;
}

.leader-card {
  background-color: #fff;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 3px 10px rgba(0,0,0,0.1);
  flex: 1 1 280px;
  max-width: 320px;
  text-align: center;
  transition: transform 0.3s ease;
}

.leader-card img {
  border-radius: 50%;
  width: 100px;
  height: 100px;
  object-fit: cover;
  margin-bottom: 15px;
}

.leader-card h3 {
  font-size: 20px;
  color: #e60023;
  margin-bottom: 5px;
}

.leader-card p {
  color: #555;
  font-size: 15px;
  margin: 5px 0;
}

.leader-card:hover {
  transform: translateY(-6px);
}
</style>
</head>
<body>
    <section id="Leadership" class="leadership-section">
  <div class="leadership-container">
    <h2>Our Leadership</h2>
    <p>Meet the individuals who guide our hospital toward excellence in healthcare and innovation.</p>
    
    <div class="leaders">
      <div class="leader-card">
        <img src="https://via.placeholder.com/150" alt="Dr. Smith">
        <h3>Dr. Sarah Smith</h3>
        <p>Chief Medical Officer</p>
        <p>With 20+ years of experience, Dr. Smith leads clinical excellence and innovation across all departments.</p>
      </div>

      <div class="leader-card">
        <img src="https://via.placeholder.com/150" alt="Mr. Johnson">
        <h3>Mr. Daniel Johnson</h3>
        <p>Chief Executive Officer</p>
        <p>A visionary leader focused on patient-centered care, strategic growth, and operational excellence.</p>
      </div>

      <div class="leader-card">
        <img src="https://via.placeholder.com/150" alt="Dr. Lee">
        <h3>Dr. Emily Lee</h3>
        <p>Director of Research</p>
        <p>Dr. Lee oversees clinical trials and research to ensure innovation in treatments and technologies.</p>
      </div>
    </div>
  </div>
</section>

</body>
</html>