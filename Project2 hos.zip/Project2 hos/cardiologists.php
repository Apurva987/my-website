<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Cardiologists - Hospital</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      color: #333;
    }

    header {
      background-color: rgba(242, 22, 44, 0.9);
      color: white;
      text-align: center;
      padding: 30px 20px;
    }

    .container {
      max-width: 1100px;
      margin: 30px auto;
      padding: 0 20px;
    }

    .doc-card {
      background: #fff;
      border-left: 6px solid #f2162c;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      margin-bottom: 25px;
      display: flex;
      align-items: center;
      gap: 20px;
      padding: 20px;
      animation: fadeIn 0.5s ease-in-out;
    }

    .doc-card img {
      width: 120px;
      height: 120px;
      object-fit: cover;
      border-radius: 50%;
      border: 2px solid #ddd;
    }

    .doc-info h3 {
      margin-bottom: 10px;
      color: #f2162c;
    }

    .doc-info p {
      font-size: 14px;
      line-height: 1.6;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    footer {
      background: #eee;
      text-align: center;
      padding: 15px;
      font-size: 14px;
      margin-top: 40px;
    }
  </style>
</head>
<body>

  <header>
    <h1>❤️ Cardiologists</h1>
    <p>Expert heart care from leading cardiology specialists</p>
  </header>

  <div class="container">

    <div class="doc-card">
      <img src="https://via.placeholder.com/120?text=Dr+Agarwal" alt="Dr. Agarwal">
      <div class="doc-info">
        <h3>Dr. Rajeev Agarwal</h3>
        <p>MBBS, MD, DM (Cardiology)<br>
        Specialization: Interventional cardiology, heart failure, angioplasty<br>
        Experience: 18+ years</p>
      </div>
    </div>

    <div class="doc-card">
      <img src="https://via.placeholder.com/120?text=Dr+Sen" alt="Dr. Sen">
      <div class="doc-info">
        <h3>Dr. Priya Sen</h3>
        <p>MBBS, MD (Medicine), DM (Cardiology)<br>
        Expertise in: Electrophysiology, pacemaker implantation, arrhythmia<br>
        Experience: 12 years</p>
      </div>
    </div>

    <div class="doc-card">
      <img src="https://via.placeholder.com/120?text=Dr+Patel" alt="Dr. Patel">
      <div class="doc-info">
        <h3>Dr. Kunal Patel</h3>
        <p>MBBS, DNB, DM (Cardiology)<br>
        Focus: Pediatric cardiology, preventive heart care, cardiac rehab<br>
        Experience: 10 years</p>
      </div>
    </div>

  </div>

  <footer>
    &copy; 2025 Hospital. All rights reserved.
  </footer>

</body>
</html>
