<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Neurologists - Hospital</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f9f9f9;
      color: #333;
      line-height: 1.6;
    }

    header {
      background-color: rgba(242, 22, 44, 0.9);
      color: white;
      padding: 20px;
      text-align: center;
    }

    .container {
      max-width: 1100px;
      margin: 30px auto;
      padding: 0 20px;
    }

    .doc-card {
      background: #fff;
      padding: 20px;
      border-left: 5px solid #f2162c;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      margin-bottom: 20px;
      display: flex;
      gap: 20px;
      align-items: center;
      animation: fadeIn 0.5s ease-in;
    }

    .doc-card img {
      width: 120px;
      height: 120px;
      object-fit: cover;
      border-radius: 50%;
      border: 2px solid #ddd;
    }

    .doc-info h3 {
      margin-bottom: 8px;
      color: #f2162c;
    }

    .doc-info p {
      font-size: 14px;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    footer {
      background: #eee;
      text-align: center;
      padding: 15px;
      font-size: 14px;
      margin-top: 40px;
    }
  </style>
</head>
<body>

  <header>
    <h1>🧠 Our Neurologists</h1>
    <p>Meet our expert team of brain and nervous system specialists</p>
  </header>

  <div class="container">

    <div class="doc-card">
      <img src="https://via.placeholder.com/120x120.png?text=Dr+1" alt="Dr. A">
      <div class="doc-info">
        <h3>Dr. Anita Sharma</h3>
        <p>MBBS, MD, DM (Neurology)<br>Specialist in Stroke, Epilepsy, and Headaches<br>Experience: 15+ years</p>
      </div>
    </div>

    <div class="doc-card">
      <img src="https://via.placeholder.com/120x120.png?text=Dr+2" alt="Dr. B">
      <div class="doc-info">
        <h3>Dr. Ramesh Iyer</h3>
        <p>MBBS, DM (Neurophysiology)<br>Focus: Multiple Sclerosis, Parkinson’s, Neuromuscular Disorders<br>Experience: 18 years</p>
      </div>
    </div>

    <div class="doc-card">
      <img src="https://via.placeholder.com/120x120.png?text=Dr+3" alt="Dr. C">
      <div class="doc-info">
        <h3>Dr. Pooja Nair</h3>
        <p>MBBS, MD, DNB (Neurology)<br>Expertise in pediatric neurology and rare genetic disorders<br>Experience: 10 years</p>
      </div>
    </div>

  </div>

  <footer>
    &copy; 2025 Hospital. All rights reserved.
  </footer>

</body>
</html>
