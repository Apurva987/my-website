<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Book Appointment</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(to right, #f8f9fa, #e0e0e0);
      padding: 40px;
      color: #333;
    }

    .appointment-container {
      max-width: 600px;
      background-color: #fff;
      margin: auto;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
      animation: fadeIn 0.8s ease;
    }

    h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #c8102e;
    }

    label {
      display: block;
      margin-top: 15px;
      font-weight: bold;
    }

    input, select, textarea {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 15px;
    }

    textarea {
      resize: vertical;
    }

    .submit-btn {
      background-color: #c8102e;
      color: white;
      border: none;
      padding: 12px 20px;
      border-radius: 5px;
      font-size: 16px;
      margin-top: 20px;
      cursor: pointer;
      width: 100%;
    }

    .submit-btn:hover {
      background-color: #a60d24;
    }

    .success { color: green; margin-top: 20px; }
    .error { color: red; margin-top: 20px; }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>

  <div class="appointment-container">
    <h2>Book an Appointment</h2>
    <form action="" method="POST">
      <label for="name">Full Name</label>
      <input type="text" id="name" name="name" required>

      <label for="email">Email Address</label>
      <input type="email" id="email" name="email" required>

      <label for="phone">Phone Number</label>
      <input type="tel" id="phone" name="phone" required>

      <label for="department">Department</label>
      <select id="department" name="department" required>
        <option value="">Select Department</option>
        <option value="Neurology">Neurology</option>
        <option value="Pediatrics">Pediatrics</option>
        <option value="Cardiology">Cardiology</option>
        <option value="Dermatology">Dermatology</option>
      </select>

      <label for="date">Appointment Date</label>
      <input type="date" id="date" name="date" required>

      <button type="submit" class="submit-btn" name="submit">Submit Appointment</button>
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $department = $_POST['department'];
        $date = $_POST['date'];

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "hospital";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            echo "<p class='error'>Connection failed: " . $conn->connect_error . "</p>";
        } else {
            // Use prepared statement to avoid SQL injection
            $stmt = $conn->prepare("INSERT INTO Patientinfo (Name, Email, phone, department, date) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $name, $email, $phone, $department, $date);

            if ($stmt->execute()) {
                echo "<p class='success'>Patient information submitted successfully!</p>";
            } else {
                echo "<p class='error'>Error: " . $stmt->error . "</p>";
            }

            $stmt->close();
            $conn->close();
        }
    }
    ?>
  </div>

</body>
</html>