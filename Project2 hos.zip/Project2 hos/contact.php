<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Us - Hospital</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      color: #333;
    }

    header {
      background-color: rgba(242, 22, 44, 0.9);
      color: #fff;
      padding: 30px 20px;
      text-align: center;
    }

    .container {
      max-width: 1000px;
      margin: 30px auto;
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      border-radius: 8px;
    }

    h2 {
      margin-bottom: 20px;
      color: #f2162c;
    }

    .contact-info, .contact-form, .map {
      margin-bottom: 30px;
    }

    .contact-info p {
      margin-bottom: 10px;
      font-size: 16px;
    }

    form {
      display: grid;
      gap: 15px;
    }

    input, textarea {
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 15px;
    }

    textarea {
      resize: vertical;
      min-height: 100px;
    }

    button {
      background-color: #f2162c;
      color: #fff;
      border: none;
      padding: 12px;
      font-size: 16px;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button:hover {
      background-color: #c51120;
    }

    .map iframe {
      width: 100%;
      height: 400px;
      border: 0;
      border-radius: 8px;
    }

    footer {
      text-align: center;
      padding: 15px;
      background: #eee;
      margin-top: 40px;
      font-size: 14px;
    }
  </style>
</head>
<body>

  <header>
    <h1>📞 Contact Us</h1>
    <p>We're here to assist you 24/7</p>
  </header>

  <div class="container">
    <div class="contact-info">
      <h2>Hospital Address</h2>
      <p>🏥 SHARADDHA HOSPITAL</p>
      <p>123 Health Avenue, Wellness City, Islampur 456789</p>
      <p>📞 Phone: +1 (123) 456-7890</p>
      <p>✉️ Email: contact@.SHARADDHA HOSPITALcom</p>
      <p>🕒 Hours: Mon - Sat, 8:00 AM to 8:00 PM</p>
    </div>

    <div class="map">
      <h2>Find Us on Map</h2>
      <!-- Replace the src URL with your hospital's actual location -->
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3732.191635905629!2d75.70000000000002!3d17.050000000000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc4a4d6f0f6b6f1%3A0x8ff6d29006e6c0c1!2sIslampur%2C%20Maharashtra%20415009%2C%20India!5e0!3m2!1sen!2sin!4v1718181812345!5m2!1sen!2sin"
        allowfullscreen=""
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade">
      </iframe>
    </div>

    <div class="contact-form">
      <h2>Send Us a Message</h2>
      <form action="submit_form.php" method="post">
        <input type="text" name="name" placeholder="Your Full Name" required />
        <input type="email" name="email" placeholder="Your Email Address" required />
        <input type="tel" name="phone" placeholder="Phone Number" />
        <button type="submit">Submit</button>
      </form>
    </div>
  </div>

  <footer>
    &copy; 2025 Sunshine Multispecialty Hospital. All rights reserved.
  </footer>

</body>
</html>
