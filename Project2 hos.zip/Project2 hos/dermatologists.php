<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dermatologists - Hospital</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      color: #333;
    }

    header {
      background-color: rgba(242, 22, 44, 0.9);
      color: white;
      text-align: center;
      padding: 30px 20px;
    }

    .container {
      max-width: 1100px;
      margin: 30px auto;
      padding: 0 20px;
    }

    .doc-card {
      background: #fff;
      border-left: 6px solid #f2162c;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      margin-bottom: 25px;
      display: flex;
      align-items: center;
      gap: 20px;
      padding: 20px;
      animation: fadeIn 0.5s ease-in-out;
    }

    .doc-card img {
      width: 120px;
      height: 120px;
      object-fit: cover;
      border-radius: 50%;
      border: 2px solid #ddd;
    }

    .doc-info h3 {
      margin-bottom: 10px;
      color: #f2162c;
    }

    .doc-info p {
      font-size: 14px;
      line-height: 1.6;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    footer {
      background: #eee;
      text-align: center;
      padding: 15px;
      font-size: 14px;
      margin-top: 40px;
    }
  </style>
</head>
<body>

  <header>
    <h1>🧴 Dermatologists</h1>
    <p>Skin care by board-certified dermatology experts</p>
  </header>

  <div class="container">

    <div class="doc-card">
      <img src="https://via.placeholder.com/120?text=Dr+Mehra" alt="Dr. Mehra">
      <div class="doc-info">
        <h3>Dr. Sanjay Mehra</h3>
        <p>MBBS, MD (Dermatology)<br>
        Specialization: Psoriasis, eczema, acne treatment, laser therapies<br>
        Experience: 16+ years</p>
      </div>
    </div>

    <div class="doc-card">
      <img src="https://via.placeholder.com/120?text=Dr+Chopra" alt="Dr. Chopra">
      <div class="doc-info">
        <h3>Dr. Neha Chopra</h3>
        <p>MBBS, DNB Dermatology<br>
        Expertise: Cosmetic dermatology, chemical peels, Botox & fillers<br>
        Experience: 10+ years</p>
      </div>
    </div>

    <div class="doc-card">
      <img src="https://via.placeholder.com/120?text=Dr+Iqbal" alt="Dr. Iqbal">
      <div class="doc-info">
        <h3>Dr. Ayesha Iqbal</h3>
        <p>MBBS, MD (Skin & VD)<br>
        Focus: Pediatric dermatology, hair loss, fungal infections<br>
        Experience: 8 years</p>
      </div>
    </div>

  </div>

  <footer>
    &copy; 2025 Hospital. All rights reserved.
  </footer>

</body>
</html>
