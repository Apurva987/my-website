<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Awards - Hospital</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background: #f9f9f9;
      color: #333;
      line-height: 1.6;
    }

    header {
      background-color: rgba(242, 22, 44, 0.9);
      color: white;
      padding: 20px;
      text-align: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .container {
      max-width: 1100px;
      margin: 30px auto;
      padding: 0 20px;
    }

    .award-card {
      background: #fff;
      padding: 20px;
      margin-bottom: 20px;
      border-left: 5px solid #f2162c;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      animation: fadeIn 0.5s ease-in;
    }

    .award-card h3 {
      margin-bottom: 10px;
      color: #f2162c;
    }

    .award-card p {
      font-size: 15px;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    footer {
      background: #eee;
      text-align: center;
      padding: 15px;
      font-size: 14px;
      margin-top: 40px;
    }
  </style>
</head>
<body>

  <header>
    <h1>🏅 Hospital Awards & Recognitions</h1>
    <p>Celebrating our achievements and commitment to healthcare excellence</p>
  </header>

  <div class="container">

    <div class="award-card">
      <h3>National Quality Award 2023</h3>
      <p>Recognized by the National Healthcare Board for exceptional patient care and clinical standards.</p>
    </div>

    <div class="award-card">
      <h3>Excellence in Cardiology 2022</h3>
      <p>Our cardiology department was ranked among the top 5 in the country for innovative treatments and outcomes.</p>
    </div>

    <div class="award-card">
      <h3>Best Pediatric Hospital - South Region 2021</h3>
      <p>Awarded by the Healthcare Review Magazine for outstanding pediatric care and child-friendly infrastructure.</p>
    </div>

    <div class="award-card">
      <h3>ISO 9001:2015 Certification</h3>
      <p>Certified for our quality management system, continuous improvement, and patient safety practices.</p>
    </div>

  </div>

  <footer>
    &copy; 2025 Hospital. All rights reserved.
  </footer>

</body>
</html>
